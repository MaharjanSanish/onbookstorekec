package com.kec.onbookstoremvc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "CONTACT")

public class Contact {

	@Id
	@GeneratedValue
	private Long id;
	

	@Column(name = "Email")
	private String email;

	@Column(name = "Telephone_no")
	private String telephoneno;


	@Column(name = "Mobile_no")
	private String mobileno;

	
}
