package com.kec.onbookstoremvc.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.kec.onbookstoremvc.dao.AdminDoa;
import com.kec.onbookstoremvc.model.Admin;
import com.kec.onbookstoremvc.model.User;

@Controller
public class AdminController {
	
	@RequestMapping(value = "/adminlogin", method = RequestMethod.GET)
	public String adminloginGET(HttpSession session) {
		
	
		return "adminlogin";}
	
	@RequestMapping(value = "/adminback", method = RequestMethod.GET)
	public String adminbackGET(HttpSession session) {
		
	
		return "login";}
	


	public  boolean checkusersession(String activeuser) {
		if (activeuser ==null){
		
			return false;	
			
		}
		else
			return true;
	}
	
	@RequestMapping(value = "/adminpage", method = RequestMethod.GET)
	public String adminpageGET(HttpSession session,Model model,Admin admin) {
/*		session.setAttribute ("activeUser",admin.getUsername());
*/
		String activeuser=(String) session.getAttribute("activeAdmin");
		if(		checkusersession(activeuser)==false /*|| activeuser!=admin.getUsername()*/){
			model.addAttribute("plzlogin", "Please login first !!!");

			
			return "login";
			
		}
		return "adminpage";}
	
	

   @Autowired
	private AdminDoa adminDao;
	
   @RequestMapping(value = "/adminprofile", method = RequestMethod.GET)
	public String adminprofileGET(HttpSession session,Model model,Admin admin) {

		String activeuser=(String) session.getAttribute("activeAdmin");
		if(		checkusersession(activeuser)==false /*|| activeuser!=admin.getUsername()*/){
			model.addAttribute("plzlogin", "Please login first !!!");

			
			return "login";
			
		}
	
		return "adminpage";}
   
	  @RequestMapping(value = "/adminprofile", method = RequestMethod.POST)
	public String adminprofile(@ModelAttribute Admin admin,Model model,HttpSession session) {
	
		
		if(adminDao.validateAdmin(admin)){
			
			session.setAttribute ("activeAdmin",admin.getUsername());
			session.setMaxInactiveInterval(5*60);//5min
			return"adminpage";
		}
		else{
			//show error message in login screen.	
			model.addAttribute("loginError" , "Sorry user/password invalid! please re-login");
			return "adminlogin";
			}
	}
	
	

	


	
	
	
	

}
