package com.kec.onbookstoremvc;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import com.kec.onbookstoremvc.dao.BooksDoa;
import com.kec.onbookstoremvc.dao.UserDao;
import com.kec.onbookstoremvc.model.Books;
import com.kec.onbookstoremvc.model.User;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	@Autowired
	private BooksDoa booksDoa;

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@Autowired
	private UserDao userDao;
	
	
	
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale) {
		logger.info("Welcome home! The client locale is {}.", locale);
		return "login";//login..............adminpage
	}

	@RequestMapping(value = "/profile", method = RequestMethod.POST)
	public String profile(@ModelAttribute User user,Model model,HttpSession session) {// spring le user ko
														// object aafai banayera
														// dinxa, @
														// modelAttribute chai
														// rakhna parxa
		
		if(userDao.validateUser(user)){
			//success:Display profile
			session.setAttribute ("activeUser",user.getUsername());
			session.setMaxInactiveInterval(5*60);//5min
			model.addAttribute("booklist",booksDoa.getAll());

			return"profile";
			
		}
		else{
		//show error message in login screen.	
		model.addAttribute("loginError" , "Sorry user/password invalid! please re-login");
		return "login";
		}
		
		
	}
	
	


	public  boolean checkusersession(String activeuser) {
		if (activeuser ==null){
		
			return false;	
			
		}
		else
			return true;
	}
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpSession session) {
		
	
	session.invalidate();	
		return "login";}
	
	@RequestMapping(value = "/profile", method = RequestMethod.GET)
	public String profilePageGET(Model model,HttpSession session) {
		String activeuser=(String) session.getAttribute("activeUser");
		if(		checkusersession(activeuser)==false){
			model.addAttribute("plzlogin", "Please login first !!!");

			
			return "login";
			
		}
		model.addAttribute("booklist",booksDoa.getAll());

	
		return "profile";}
	
	
	
	

}
