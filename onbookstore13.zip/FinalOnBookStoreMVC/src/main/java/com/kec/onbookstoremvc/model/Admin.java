package com.kec.onbookstoremvc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "ADMIN")

public class Admin {
	@Id
	@GeneratedValue
	@Column(name = "admin_id")
	private Long adminid;

	@Column(name = "username")
	private String username;

	@Column(name = "password")
	private String password;
	

}
