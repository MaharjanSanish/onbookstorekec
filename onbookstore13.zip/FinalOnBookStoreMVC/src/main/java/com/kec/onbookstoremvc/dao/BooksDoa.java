package com.kec.onbookstoremvc.dao;

import java.util.List;

import com.kec.onbookstoremvc.model.Books;
import com.kec.onbookstoremvc.model.User;

public interface BooksDoa {
	void insertUpdate(Books books);
	List<Books> getAll();
	List<Books> getAllOf(String category);

	Books get(long id);
	Books get(String category);

	void delete (long id);
	 
	Books getbookbyisbn(long ISBN_13);

}
