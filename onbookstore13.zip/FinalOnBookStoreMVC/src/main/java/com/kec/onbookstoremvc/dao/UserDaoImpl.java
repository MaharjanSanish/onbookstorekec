package com.kec.onbookstoremvc.dao;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.kec.onbookstoremvc.model.Books;
import com.kec.onbookstoremvc.model.User;
import com.mysql.jdbc.PreparedStatement;

//spring use gareko...no hibernate

@Repository
public class UserDaoImpl implements UserDao{
	@Autowired
	private DataSource dataSource ;
	
	@Resource
	private SessionFactory sessionFactory;

	/*@Override
	@Transactional
	public void insertUpdate(User userAttribute) {
		Session session = sessionFactory.getCurrentSession();
		session.saveOrUpdate(userAttribute);// id chahinxa????

	}*/
	
	

	
	@Transactional
	public void insert(User userAttribute) {
		Session session = sessionFactory.getCurrentSession();
		session.save(userAttribute);// id chahinxa????

	}

	@Override
	public boolean validateUser(User user) {
    JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		
 try{
	   String sql="select username from user where username ='"+user.getUsername()+"'and password ='"+user.getPassword()+"'";
		
	System.out.println(sql);
	   
	   String dbusername= jdbcTemplate.queryForObject(sql, String.class);
		if ((dbusername != null) && (dbusername.equals(user.getUsername()))){
			
			return true;
			
		}	else {
			return false;
		}
 }catch(Exception e){
	e.printStackTrace();
	return false;

 }
	}




	@Override
	@Transactional
	public User getUserByUserName(String username) {
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(User.class);
		criteria.add(Restrictions.eq("username", username));
		User user = (User)criteria.uniqueResult();
		return user;
	}




	@Override
	public void insertupdate(User editUserModel) {
		Session session = sessionFactory.getCurrentSession();
		session.saveOrUpdate(editUserModel);		
	}

	/*public static boolean CheckUsernameExists(String username){

	    boolean usernameExists = false;
	    try{
	        PreparedStatement st = connection.prepareStatement("select * from Members where username = ? ");
	        st.setString(1, username);
	        ResultSet r1=st.executeQuery();
	        if(r1.next()){
	           usernameExists = true;
	        }
	    catch (Exception e) {
	        System.out.println("SQL Exception: "+ e.toString());
	    }
	    return usernameExists;
	}
*/
/*
	@Override
	public boolean validateUser(User user) {
    JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		
		
		return false;
	}*/
}
