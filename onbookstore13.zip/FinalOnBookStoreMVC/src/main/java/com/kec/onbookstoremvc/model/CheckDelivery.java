package com.kec.onbookstoremvc.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="CHECK_DELIVERY")

public class CheckDelivery {

	@Id
	@GeneratedValue
	private long checkdelid;
	
	@Column (name="Check_time")
	private Date checktime;
	
	@Column(name= "del_status")
	private String delstatus;
	
	
}
