package com.kec.onbookstoremvc.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
@Entity
@Table(name = "BOOKS")

public class Books {

	@Id
	@GeneratedValue
	private Long id;

	@Column(name = "book_name")
	private String bookname;

	@Column(name = "author_name")
	private String authorname;

	@Column(name = "publisher")
	private String publisher;

	@Column(name = "language")
	private String language;

	/*@Size(min = 13, max = 13)*/
	@Column(name = "ISBN_13")
	private long ISBN_13;

	@Column(name = "price")
	private int price;

	@Column(name = "category")
	private String category;

	@Column(name = "description")
	private String description;

	@Column(name = "book_image_name")
	private String bookimagename;

	@Column(name = "book_pdf_name")
	private String bookpdfname;

	@Column(name = "quantity")
	private int quantity;
	
	@Column (name="pub_date")
	private Date pubdate;
	
	
	@Transient
	private MultipartFile bookimage;
	
	
	@Transient
	private MultipartFile pdf;
	
	
}
