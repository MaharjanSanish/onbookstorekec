package com.kec.onbookstoremvc.dao;

import java.util.List;

import com.kec.onbookstoremvc.model.OrderDetail;

public interface OrderDetailDao {
	

	void insertUpdate(OrderDetail orderDetail);
	List<OrderDetail> getAll();
	List<OrderDetail> getAllOrderOfParticularUser();


	OrderDetail get(long id);

	void delete (long id);

}
