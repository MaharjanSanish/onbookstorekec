package com.kec.onbookstoremvc.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.kec.onbookstoremvc.dao.ContactDoa;
import com.kec.onbookstoremvc.model.Contact;

@Controller

public class ContactControler {
	
	@Autowired
	private ContactDoa contactDoa;
	
	public  boolean checkusersession(String activeuser) {
		if (activeuser ==null){
		
			return false;	
			
		}
		else
			return true;
	}

	@RequestMapping(value = "/contact", method = RequestMethod.GET)
	public String viewBooksGET(Model model,HttpSession session) {
		String activeuser=(String) session.getAttribute("activeUser");
		if(		checkusersession(activeuser)==false){
			model.addAttribute("plzlogin", "Please login first !!!");

			
			return "login";
			
		}

		model.addAttribute("contactlist", contactDoa.getAll());

		return "contactDisplay";

	}
	
	/*@RequestMapping(value = "/contactinput", method = RequestMethod.POST)
	public String contactPOST(@ModelAttribute Contact contact, Model model) {

		
		ContactDoa.insertUpdate(contact);

		model.addAttribute("contact", new contact());
		model.addAttribute("booklist", contactDoa.getall());
		model.addAttribute("successMsg", "Contacts edited successfully!!!");

		return "redirect:contactinput";
	}*/
}
