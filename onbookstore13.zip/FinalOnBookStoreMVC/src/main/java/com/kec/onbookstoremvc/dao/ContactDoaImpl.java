package com.kec.onbookstoremvc.dao;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.kec.onbookstoremvc.model.Contact;
@Repository

public class ContactDoaImpl implements ContactDoa {
	
	@Resource
	private SessionFactory sessionFactory;

	@Override
	public void insertUpdate(Contact contact) {
		Session session = sessionFactory.getCurrentSession();
		session.saveOrUpdate(contact);// id chahinxa????		
	}

	
		@Override
		@Transactional
		public List<Contact> getAll() {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(Contact.class);// query ma
																	// "where"garne
																	// kaam yesma
																	// criteria le
																	// garxa

			// criteria.add(Restrictions.eq("publisher","sakun"));

			List<Contact> contactist = (List<Contact>) criteria.list();

			return contactist;
		}


	

	
}
