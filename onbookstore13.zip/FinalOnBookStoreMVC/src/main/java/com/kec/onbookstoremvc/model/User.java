package com.kec.onbookstoremvc.model;

import javax.persistence.Column;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "USER")
public class User {
	@Id // primary key
	@GeneratedValue // auto increment
	private Long id;

	@Column(name = "f_name")
	private String fname;

	@Column(name = "l_name")
	private String lname;

	@Column(name = "phone")
	private long phone;

	@Column(name = "wishlist")
	private String wishlist;

	/*
	 * @NotEmpty
	 * 
	 * @Email
	 */
	@Column(name = "email")
	private String email;

	@Column(name = "username")
	private String username;

	/*
	 * @NotEmpty(message = "Please enter your password.")
	 * 
	 * @Size(min = 6, max = 15, message =
	 * "Your password must between 6 and 15 characters")
	 */
	@Column(name = "password")
	private String password;

	@Column(name = "passwordConfirm")
	private String passwordConfirm;

	@Column(name = "address")
	private String address;

	@OneToMany
	@JoinTable(name = "User_order", joinColumns = @JoinColumn(name = "userid"), inverseJoinColumns = @JoinColumn(name = "orderid"))

    private List<OrderDetail> orderDetails;

}
