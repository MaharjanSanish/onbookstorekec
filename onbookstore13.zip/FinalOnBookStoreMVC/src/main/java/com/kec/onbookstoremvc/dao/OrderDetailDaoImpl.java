package com.kec.onbookstoremvc.dao;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.kec.onbookstoremvc.model.OrderDetail;

@Repository
public class OrderDetailDaoImpl implements OrderDetailDao {
	@Resource
	private SessionFactory sessionFactory;


	@Override
	public void insertUpdate(OrderDetail orderDetail) {
		Session session = sessionFactory.getCurrentSession();
		session.saveOrUpdate(orderDetail);		
	}

	@Override
	public List<OrderDetail> getAll() {
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(OrderDetail.class);// query ma
																// "where"garne
																// kaam yesma
																// criteria le
																// garxa

		// criteria.add(Restrictions.eq("publisher","sakun"));

		List<OrderDetail> orderDetailslist = (List<OrderDetail>) criteria.list();

		return orderDetailslist;
	}

	@Override
	public OrderDetail get(long id) {
		Session session = sessionFactory.getCurrentSession();
		OrderDetail orderDetail = (OrderDetail) session.get(OrderDetail.class, id);

		return orderDetail;
	}

	@Override
	public void delete(long id) {
		Session session = sessionFactory.getCurrentSession();
		OrderDetail orderDetailid = (OrderDetail) session.get(OrderDetail.class, id);
		session.delete(orderDetailid);		
	}

	@Override
	public List<OrderDetail> getAllOrderOfParticularUser() {
		Session session = sessionFactory.getCurrentSession();
/*		String activeuser=(String)session.getAttribute("activeUser");
*/		Criteria criteria = session.createCriteria(OrderDetail.class);// query ma
																// "where"garne
																// kaam yesma
																// criteria le
																// garxa

/*		criteria.add(Restrictions.eq("username",activeuser));
*/
		List<OrderDetail> orderDetailslist = (List<OrderDetail>) criteria.list();

		return orderDetailslist;
	}
	
	

}
