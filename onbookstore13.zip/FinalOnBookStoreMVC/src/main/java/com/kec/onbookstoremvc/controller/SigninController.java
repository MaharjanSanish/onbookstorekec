package com.kec.onbookstoremvc.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.kec.onbookstoremvc.dao.UserDao;
import com.kec.onbookstoremvc.model.User;

@Controller
public class SigninController {
	@Resource
	private SessionFactory sessionFactory;

	@Autowired
	private UserDao userDao;

	@RequestMapping(value = "/signin", method = RequestMethod.GET)
	public String booksGET(Model model) {

		model.addAttribute("userAttribute", new User());
		return "signInForm";
	}

	@RequestMapping(value = "/signinback", method = RequestMethod.GET)
	public String signinbackGET(HttpSession session) {

		return "login";
	}

	@RequestMapping(value = "/signin", method = RequestMethod.POST)
	public String signinPOST(@ModelAttribute User userAttribute, Model model) {

		String username = userAttribute.getUsername();
		if (userDao.getUserByUserName(username) != null) { // user exist
			model.addAttribute("duplicateUserError", "Duplicate User name");
			model.addAttribute("userAttribute", userAttribute);
			return "signInForm";
		}

		/*String password = userAttribute.getPassword();
		String passwordConfirm = userAttribute.getPasswordConfirm();
		*/
		if ( !(userAttribute.getPassword().equals( userAttribute.getPasswordConfirm()))) { // no matching password
			model.addAttribute("passwordMismatch", "Password does not match");
			model.addAttribute("userAttribute", userAttribute);
			return "signInForm";
		}

		// save in db
		userDao.insert(userAttribute);
		model.addAttribute("userAttribute", new User());

		model.addAttribute("successMsg", "Signin successfull !!!");

		return "login";
	}

	@RequestMapping(value = "/editProfile", method = RequestMethod.GET) // ....................gardai
																		// xu
	public String editProfileGET(@ModelAttribute User editUserModel, Model model, HttpSession session) {
		String username = (String) session.getAttribute("activeUser");
		User user = userDao.getUserByUserName(username);
		model.addAttribute("editUserModel", user);
		return "editProfile";

		
		
	}

	@RequestMapping(value = "/editProfile", method = RequestMethod.POST)
	public String editProfilePOST(@ModelAttribute User editUserModel, Model model, HttpSession session) {

		String username = editUserModel.getUsername();
		if (username != session.getAttribute("activeUser") && (userDao.getUserByUserName(username) != null)) { // user
																												// exist
			model.addAttribute("duplicateUserError", "Duplicate User name");
			model.addAttribute("editUserModel", editUserModel);
			return "editProfile";
		}

		// save in db
		userDao.insertupdate(editUserModel);
		model.addAttribute("editUserModel", new User());

		model.addAttribute("successMsg", "Profile update successfull !!!");

		return "profile";
		
		
		
	}

}
