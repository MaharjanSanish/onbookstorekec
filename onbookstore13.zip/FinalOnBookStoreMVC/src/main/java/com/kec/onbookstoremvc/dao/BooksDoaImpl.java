package com.kec.onbookstoremvc.dao;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.kec.onbookstoremvc.model.Books;
import com.kec.onbookstoremvc.model.User;

//use of hibernate along with spring
@Repository
public class BooksDoaImpl implements BooksDoa {

	@Resource
	private SessionFactory sessionFactory;

	@Override
	@Transactional
	public void insertUpdate(Books books) {
		Session session = sessionFactory.getCurrentSession();
		session.saveOrUpdate(books);// id chahinxa????

	}

	@Override
	@Transactional
	public List<Books> getAll() {
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Books.class);// query ma
																// "where"garne
																// kaam yesma
																// criteria le
																// garxa

		// criteria.add(Restrictions.eq("publisher","sakun"));

		List<Books> booklist = (List<Books>) criteria.list();

		return booklist;
	}

	@Transactional
	@Override
	public Books get(long id) {
		Session session = sessionFactory.getCurrentSession();
		Books book = (Books) session.get(Books.class, id);

		return book;
	}

	@Override
	@Transactional
	public void delete(long id) {
		Session session = sessionFactory.getCurrentSession();
		Books books = (Books) session.get(Books.class, id);
		session.delete(books);
	}

	@Override
	public Books get(String category) {

		Session session = sessionFactory.getCurrentSession();
		Books book = (Books) session.get(Books.class, category);

		return book;
	}

	@Override
	public List<Books> getAllOf(String category) {
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Books.class);// query ma
																// "where"garne
																// kaam yesma
																// criteria le
																// garxa

		 criteria.add(Restrictions.eq("category",category));

		List<Books> booklist = (List<Books>) criteria.list();

		return booklist;
	}

	@Override
	public Books getbookbyisbn(long ISBN_13) {
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Books.class);
		criteria.add(Restrictions.eq("ISBN_13", ISBN_13));
		Books books = (Books)criteria.uniqueResult();
		return books;	}

}
