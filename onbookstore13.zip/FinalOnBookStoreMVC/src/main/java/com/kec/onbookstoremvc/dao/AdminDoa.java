package com.kec.onbookstoremvc.dao;

import com.kec.onbookstoremvc.model.Admin;

public interface AdminDoa {

boolean validateAdmin(Admin admin);
}
