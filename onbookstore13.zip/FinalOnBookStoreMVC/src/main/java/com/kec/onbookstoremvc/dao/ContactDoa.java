package com.kec.onbookstoremvc.dao;

import java.util.List;

import com.kec.onbookstoremvc.model.Contact;

public interface ContactDoa {
	
	void insertUpdate(Contact contact);
	
	List<Contact> getAll();

}
