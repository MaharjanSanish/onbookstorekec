package com.kec.onbookstoremvc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="OrderDetail")
public class OrderDetail {
	
	@Id
	@GeneratedValue
	 private long Order_Detail_id;
	
	@Column(name = "order_quantity")
	private int orderquantity;
	
	@Column(name = "total_price")
	private float totalprice;
	
	/*@OneToOne
	@JoinColumn(name = "order_id_FK")
	private OrderViewByUser orderViewByUser;*/
	
	@OneToOne
	@JoinColumn(name="bookid_FK")
	private Books books;

/*
	@ManyToMany
	@JoinTable(name= "orderDetail_Book" , joinColumns={@JoinColumn(name="orderdetail_id")}, inverseJoinColumns={@JoinColumn(name="book_id")})
	private List<Books>books;
	*/

}
