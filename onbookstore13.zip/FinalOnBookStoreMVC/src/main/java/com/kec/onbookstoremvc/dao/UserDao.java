package com.kec.onbookstoremvc.dao;


import com.kec.onbookstoremvc.model.User;

public interface UserDao {
	
	boolean validateUser(User user);


	void insert(User userAttribute);


	//void insertUpdate(User userAttribute);
	
	User getUserByUserName(String username);


	void insertupdate(User editUserModel);








	
	

}
