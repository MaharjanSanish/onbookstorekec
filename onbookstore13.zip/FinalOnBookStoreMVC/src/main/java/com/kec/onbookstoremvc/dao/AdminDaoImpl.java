package com.kec.onbookstoremvc.dao;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.kec.onbookstoremvc.model.Admin;



@Repository
public  class AdminDaoImpl  implements AdminDoa{
	@Autowired
	private DataSource dataSource ;
	
	@Resource
	private SessionFactory sessionFactory;


	@Override
	public boolean validateAdmin(Admin admin){


		 JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		
			
		 try{
			   String sql="select username from admin where username ='"+admin.getUsername()+"'and password ='"+admin.getPassword()+"'";
				
			System.out.println(sql);
			   
			   String dbusername= jdbcTemplate.queryForObject(sql, String.class);
				if ((dbusername != null) && (dbusername.equals(admin.getUsername()))){
					
					return true;
					
				}	else {
					return false;
				}
		 }catch(Exception e){
			e.printStackTrace();
			return false;

		 }
	}
	

}
