package com.kec.onbookstoremvc.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.kec.onbookstoremvc.dao.BooksDoa;
import com.kec.onbookstoremvc.dao.OrderDetailDao;
import com.kec.onbookstoremvc.dao.UserDao;
import com.kec.onbookstoremvc.model.Admin;
import com.kec.onbookstoremvc.model.Books;
import com.kec.onbookstoremvc.model.OrderDetail;
import com.kec.onbookstoremvc.model.User;
import com.kec.onbookstoremvc.service.FileStorageService;

@Controller
public class BooksController {

	@Autowired
	private BooksDoa booksDoa;

	@Autowired
	private UserDao userDao;

	@Autowired
	private OrderDetailDao orderDetailDao;

	@InitBinder // used in special case like date
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		formatter.setLenient(true);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(formatter, true));
	}

	public boolean checkusersession(String activeuser) {
		if (activeuser == null) {

			return false;

		} else
			return true;
	}

	@RequestMapping(value = "/books", method = RequestMethod.GET)
	public String booksGET(Model model, HttpSession session, Admin admin) {
		/*
		 * session.setAttribute ("activeUser",admin.getUsername());
		 */
		String activeuser = (String) session.getAttribute("activeAdmin");
		if (checkusersession(activeuser) == false) {
			model.addAttribute("plzlogin", "Please login first !!!");

			return "login";

		}

		model.addAttribute("books", new Books());

		return "book";

	}

	@Autowired
	private FileStorageService fileStorageService;

	@RequestMapping(value = "/books", method = RequestMethod.POST)
	public String booksPOST(@ModelAttribute Books books, Model model) {

		/*
		 * long isbn = books.getISBN_13(); if (booksDoa.getbookbyisbn(isbn) !=
		 * null) { // isbn exist model.addAttribute("duplicateISBN",
		 * "Duplicate ISBN No"); model.addAttribute("books", books); return
		 * "books"; }
		 */
		// save in db
		saveBookPdf(books);

		saveBookImage(books);
		booksDoa.insertUpdate(books);

		model.addAttribute("books", new Books());
		model.addAttribute("booklist", booksDoa.getAll());
		model.addAttribute("successMsg", "Book added/edited successfully!!!");

		return "viewBooks";
	}
	/*
	 * @RequestMapping(value = "/books", method = RequestMethod.POST) public
	 * String booksdialogPOST(@ModelAttribute Books books, Model model) {
	 * 
	 * // save in db saveBookPdf(books);
	 * 
	 * saveBookImage(books); booksDoa.insertUpdate(books);
	 * 
	 * model.addAttribute("books", new Books());
	 * model.addAttribute("successMsg", "Book added successfully!!!");
	 * 
	 * return "viewbooks"; }
	 */

	private void saveBookPdf(Books books) {
		// save in drive
		MultipartFile pdf = books.getPdf();
		try {
			if (!pdf.isEmpty()) {

				books.setBookpdfname(URLEncoder.encode(pdf.getOriginalFilename(), "UTF-8"));
				fileStorageService.saveFilePdf(pdf);

			}
			booksDoa.insertUpdate(books);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void saveBookImage(Books books) {
		// save image in drive
		MultipartFile bookimage = books.getBookimage();

		try {

			if (!bookimage.isEmpty()) {
				// Save file in drive

				books.setBookimagename(URLEncoder.encode(bookimage.getOriginalFilename(), "UTF-8"));
				fileStorageService.saveFileImage(bookimage);
			}

			// Save data in db.
			booksDoa.insertUpdate(books);

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}

	@RequestMapping(value = "/viewBooks", method = RequestMethod.GET)
	public String viewBooksGET(Model model, HttpSession session, Admin admin) {
		/*
		 * session.setAttribute ("activeUser",admin.getUsername());
		 */
		String activeuser = (String) session.getAttribute("activeAdmin");
		if (checkusersession(
				activeuser) == false /* || activeuser!=admin.getUsername() */) {
			model.addAttribute("plzlogin", "Please login first !!!");

			return "login";

		}

		model.addAttribute("booklist", booksDoa.getAll());

		return "viewBooks";

	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String addBook(Model model, HttpSession session, Admin admin) {
		/*
		 * session.setAttribute ("activeUser",admin.getUsername());
		 */
		String activeuser = (String) session.getAttribute("activeAdmin");
		if (checkusersession(activeuser) == false) {
			model.addAttribute("plzlogin", "Please login first !!!");

			return "login";

		}
		model.addAttribute("book", new Books());
		return "bookDialog";
	}

	@RequestMapping(value = "{id}/edit", method = RequestMethod.GET)
	public String editBook(@PathVariable("id") Long id, Model model, HttpSession session, Admin admin) {
		/*
		 * session.setAttribute ("activeUser",admin.getUsername());
		 */
		String activeuser = (String) session.getAttribute("activeAdmin");
		if (checkusersession(activeuser) == false) {
			model.addAttribute("plzlogin", "Please login first !!!");

			return "login";

		}
		Books books = booksDoa.get(id);
		model.addAttribute("book", books);
		return "bookDialog";
	}

	@RequestMapping(value = "{id}/delete", method = RequestMethod.GET)
	public String deleteBook(@PathVariable("id") Long id, HttpSession session, Model model) {
		String activeuser = (String) session.getAttribute("activeAdmin");
		if (checkusersession(activeuser) == false) {
			model.addAttribute("plzlogin", "Please login first !!!");

			return "login";

		}
		booksDoa.delete(id);
		return "redirect:/viewBooks";
	}

	@RequestMapping(value = "/{id}/displayParticularBook", method = RequestMethod.GET)
	public String displayParticularBookGET(@PathVariable("id") Long id, Model model, HttpSession session) {
		String activeuser = (String) session.getAttribute("activeUser");
		if (checkusersession(activeuser) == false) {
			model.addAttribute("plzlogin", "Please login first !!!");

			return "login";

		}
		Books books = booksDoa.get(id);

		model.addAttribute("book", booksDoa.get(id));

		return "displayParticularBook";

	}

	@RequestMapping(value = "/{category}/displayBooksOfCategory", method = RequestMethod.GET)
	public String isplayBooksOfCategoryGET(@PathVariable("category") String category, Model model,
			HttpSession session) {

		String activeuser = (String) session.getAttribute("activeUser");
		if (checkusersession(activeuser) == false) {
			model.addAttribute("plzlogin", "Please login first !!!");

			return "login";

		}
		Books books = booksDoa.get(category);

		model.addAttribute("booklist", booksDoa.getAll());

		/*
		 * model.addAttribute("book", booksDoa.get(category));
		 */
		return "displayParticularBook";

	}

	/*
	 * @RequestMapping(value = "/{id}/orderBook", method = RequestMethod.GET)
	 */ @RequestMapping(value = "/orderBook", method = RequestMethod.GET)

	public String orderBookGET(/* @PathVariable("id") Long id, */ Model model, HttpSession session,
			OrderDetail orderDetail) {

		String activeuser = (String) session.getAttribute("activeUser");
		if (checkusersession(activeuser) == false) {
			model.addAttribute("plzlogin", "Please login first !!!");

			return "login";

		}
		/*
		 * OrderViewByUser orderViewByUser = orderBookDoa.get(id);
		 * 
		 * model.addAttribute("orderbook", orderBookDoa.get(id));// data set
		 * garna paryo
		 * 
		 * 
		 */

		orderDetailDao.insertUpdate(orderDetail);
		/*
		 * Books books = booksDoa.get(id);
		 */ User user = userDao.getUserByUserName(activeuser);
		/*
		 * OrderDetail orderDetailid = orderDetailDao.get(id);
		 */
		/*
		 * model.addAttribute("book", booksDoa.get(id));
		 */ model.addAttribute("user", userDao.getUserByUserName(activeuser));
		model.addAttribute("orderDetailid", orderDetailDao.getAllOrderOfParticularUser());

		return "viewOrderByUser";

	}

	@RequestMapping(value = "/viewOrderByUser", method = RequestMethod.GET)
	public String viewOrderByUserGET(Model model, HttpSession session) {
		String activeuser = (String) session.getAttribute("activeUser");
		if (checkusersession(activeuser) == false) {
			model.addAttribute("plzlogin", "Please login first !!!");

			return "login";

		}

		model.addAttribute("orderDetailslist", orderDetailDao.getAllOrderOfParticularUser());

		return "viewOrderByUser";

	}

	@RequestMapping(value = "{id}/deleteOrder", method = RequestMethod.GET)
	public String deleteOrder(@PathVariable("id") Long id, HttpSession session, Model model) {

		String activeuser = (String) session.getAttribute("activeUser");
		if (checkusersession(activeuser) == false) {
			model.addAttribute("plzlogin", "Please login first !!!");

			return "login";

		}
		orderDetailDao.delete(id);
		return "redirect:/viewOrderByUser";
	}

	@RequestMapping(value = "/viewOrderByAdmin", method = RequestMethod.GET)
	public String viewOrderByAdminGET(Model model, HttpSession session, Admin admin) {
		session.setAttribute("activeUser", admin.getUsername());

		String activeuser = (String) session.getAttribute("activeAdmin");
		if (checkusersession(activeuser) == false) {
			model.addAttribute("plzlogin", "Please login first !!!");

			return "login";

		}

		model.addAttribute("orderDetailslist", orderDetailDao.getAll());

		return "viewOrderByAdmin";

	}

	/*
	 * @RequestMapping(value = "/ upload", method = RequestMethod.GET) public
	 * String uploadFileGET() {
	 * 
	 * return "book"; }
	 * 
	 * @RequestMapping(value = "/upload", method = RequestMethod.POST) public
	 * String uploadPOST(@RequestParam("file") MultipartFile file, Model model)
	 * throws UnsupportedEncodingException {
	 * 
	 * if (!file.isEmpty()) {
	 * 
	 * fileStorageService.saveFile(file); model.addAttribute("fileNames",
	 * URLEncoder.encode(file.getOriginalFilename(), "UTF-8"));
	 * 
	 * }
	 * 
	 * return "book";
	 * 
	 * }
	 */

	@RequestMapping(value = "/downloadimage", method = RequestMethod.GET)
	public void downloadimg(@RequestParam("bookimagename") String bookimagename, HttpServletResponse response)
			throws IOException {

		if (!StringUtils.isEmpty(bookimagename)) {// filename not equal to null
													// and
													// not equal to
													// ""..StringUtils.isEmpty(fileName

			bookimagename = URLDecoder.decode(bookimagename, "UTF-8");

			File imagePath = new File(FileStorageService.FILE_PATH_IMAGE + bookimagename);
			if (imagePath.exists()) {

				String ext = FilenameUtils.getExtension(bookimagename);

				// Set Header
				if (ext.equals("png") || ext.equals("jpg") || ext.equals("jpeg")) {
					response.setContentType("image/" + ext);
				} /*
					 * else if (ext.equals("pdf")) {
					 * response.setContentType("application/" + ext); }
					 */
				response.setHeader("Content-Disposition", "attachment;bookimagename=" + bookimagename);

				// Copy file stream and write in response writer or outputstream
				FileCopyUtils.copy(new FileInputStream(imagePath), response.getOutputStream());

				// OR
				/*
				 * PrintWriter out = response.getWriter(); FileInputStream fin =
				 * new FileInputStream(imagePath);
				 * 
				 * int i = 0; while ((i = fin.read()) != -1) { out.write(i); }
				 * fin.close(); out.close();
				 */
			}

		}

	}

	@RequestMapping(value = "/downloadpdf", method = RequestMethod.GET)
	public String downloadpdf(@RequestParam("bookpdfname") String bookpdfname, HttpServletResponse response,Model model)
			throws IOException {

		if (!StringUtils.isEmpty(bookpdfname)) {// filename not equal to null
												// and
												// not equal to
												// ""..StringUtils.isEmpty(fileName

			bookpdfname = URLDecoder.decode(bookpdfname, "UTF-8");

			File pdfPath = new File(FileStorageService.FILE_PATH_PDF + bookpdfname);
			if (pdfPath.exists()) {

				String ext = FilenameUtils.getExtension(bookpdfname);

				// Set Header
				/*
				 * if (ext.equals("png") || ext.equals("jpg") ||
				 * ext.equals("jpeg")) { response.setContentType("image/" +
				 * ext); }
				 */
				if (ext.equals("pdf")) {
					response.setContentType("application/" + ext);
				}

				response.setHeader("Content-Disposition", "attachment;bookpdfname=" + bookpdfname);

				// Copy file stream and write in response writer or outputstream
				FileCopyUtils.copy(new FileInputStream(pdfPath), response.getOutputStream());

				// OR
				/*
				 * PrintWriter out = response.getWriter(); FileInputStream fin =
				 * new FileInputStream(imagePath);
				 * 
				 * int i = 0; while ((i = fin.read()) != -1) { out.write(i); }
				 * fin.close(); out.close();
				 */
				return "redirect:/displayParticularBook";
			}

		}
		model.addAttribute("nopdf", "Sorry, no PDF for this book...Search for other books !!!");
		model.addAttribute("booklist",booksDoa.getAll());

		return "profile";

	}

}
