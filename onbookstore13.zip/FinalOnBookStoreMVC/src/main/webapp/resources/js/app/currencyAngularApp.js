angular.module('currencyApp',[])//'angular' lekhna parxa angular lai
.controller('CurrencyController', function($scope, $http){//angular ko ajax bhaneko "$http" ho
	$scope.rates = [];
	$http.get('http://api.fixer.io/latest?base=USD').then(function(result) {
       $scope.rates = result.data.rates;//'jquery' lekhepani hunxa tara shortcut naam chai '$'  ho
       
    });			
});